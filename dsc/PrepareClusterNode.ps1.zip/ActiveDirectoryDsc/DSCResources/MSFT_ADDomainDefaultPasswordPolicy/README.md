# Description

The ADDomainDefaultPasswordPolicy DSC resource will manage an Active Directory domain's default password policy.

## Requirements

* Target machine must be running Windows Server 2008 R2 or later.
